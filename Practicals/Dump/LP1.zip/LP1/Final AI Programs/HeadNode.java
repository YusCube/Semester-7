package astargraph;

importjava.util.ArrayList;
importjava.util.Iterator;

public class HeadNode                                           // Adjacency list head node
{
private String name;                                        // node name
privateintgx;                                             // gx value
privateinthx;                                             // heuristic value hx
privateintfx;                                             // fx = gx+hx value
privateArrayList<Node>adjnodes = new ArrayList<>();       // Adjacent nodes list

publicHeadNode()                                           // Initialize gx,hx and fx to infinity 
    {
gx=hx=999;
fx = gx+hx;
    }

publicintgetGx() {
returngx;
    }

public void setGx(intgx) {                                 // Set gx and update fxaccordigly
this.gx = gx;
setFx(this.gx+hx);
System.out.println("\nFx of node "+this.name+" = "+this.fx);
    }

publicintgetHx() {                                  
returnhx;
    }

public void setHx(inthx) {                                 // Set hx and update fx accordingly
this.hx = hx;
setFx(this.hx+gx);
    }

publicintgetFx() {
returnfx;
    }

public void setFx(intfx) {
this.fx = fx;
    }

public void setName(String name) {
        this.name = name;
    }

public String getName() {
return name;
    }

public void setNodeInfo(String name,int distance)           // Set adjacent node name and distance
    {
        Node n = new Node(name,distance);
adjnodes.add(n);                                        // Add node to list
    }

publicArrayListgetNodeList()
    {
returnadjnodes;
    }

public void displayNodeList()                              // Display adjacent nodes list (name,distance)
    {

        Iterator i = adjnodes.iterator();
if(i.hasNext())
        {
            Node temp= (Node)i.next();
System.out.print("("+temp.getName()+","+temp.getDistance()+")");

        }
while(i.hasNext())
        {
            Node temp= (Node)i.next();
System.out.print(", ("+temp.getName()+","+temp.getDistance()+")");
        }
    }
}

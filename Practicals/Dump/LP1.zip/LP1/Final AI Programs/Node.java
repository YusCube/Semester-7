packageastargraph;
public class Node                                           // Adjacent node name and distance
{
    String name;
int distance;

public Node(String name, intdist)
    {
        this.name = name;
this.distance = dist;
    }

publicintgetDistance() 
	{
return distance;
    }

public String getName() 
	{
return name;
    }

public void setDistance(int distance) 
	{
this.distance = distance;
    }

public void setName(String name) 
	{
        this.name = name;
    }
}

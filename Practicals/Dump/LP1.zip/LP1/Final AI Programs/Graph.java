packageastargraph;

importjava.util.ArrayList;
importjava.util.Scanner;
importjavax.swing.JOptionPane;


public class Graph {                                                  // Class for graph

ArrayList<HeadNode>headNodesList;
int n;

public Graph(int size)                                            // Initialize size and head node list
    {
this.n = size;
headNodesList = new ArrayList<>();
    }

public void initGraph()                                           // Initialize graph nodes and edges
    {
        Scanner sc = new Scanner(System.in);
for(int i=0;i<n;i++)                                          // Accept node names and their heuristic values
        {

HeadNodehn = new HeadNode();
hn.setName(JOptionPane.showInputDialog("Enter the name of node " +(i+1)+" : "));
hn.setHx(Integer.parseInt(JOptionPane.showInputDialog("Enter the heuristic value of node " +(i+1)+" : ")));
headNodesList.add(hn);

        }
for(int i=0;i<n;i++)
        {
HeadNodetempHeadNode = headNodesList.get(i);

while(true)                                              // Accept adjacent nodes and their distances
            {
                String name = tempHeadNode.getName();
                String ans = JOptionPane.showInputDialog("\nDo you want to add any adjacent node to node "+ name + "? (y/n) : ");
if(ans.equals("n")  || ans.equals("N"))
break;
               // sc.skip("\n");
                String tempName=JOptionPane.showInputDialog("Enter the name of adjacent node of "+ name + " : ");
                //sc.skip("\n");
inttempDistance=Integer.parseInt(JOptionPane.showInputDialog("Enter distance between nodes " + name + " and " + tempName+ " :"));

tempHeadNode.setNodeInfo(tempName,tempDistance);
headNodesList.set(i, tempHeadNode);

            }
        }
    }

public void displayGraph()                                       // Display graph adjacency list
    {
for(int i=0;i<n;i++)
        {
HeadNodetempHeadNode = headNodesList.get(i);
System.out.print("\n"+ tempHeadNode.getName() + " (hx = "+tempHeadNode.getHx()+") : ");
tempHeadNode.displayNodeList();
        }
System.out.println("");
    }

publicintgetIndex(String name)                                 // Get index for given name
    {
for(int i=0;i<n;i++)
        {
HeadNodetempHeadNode = headNodesList.get(i);
if(tempHeadNode.getName().equals(name))
return i;
        }
return -1;
    }

publicArrayListgetNeighbours(String node)                      // Get neighbour nodes list
    {
intheadIndex=getIndex(node);
returnheadNodesList.get(headIndex).getNodeList();
    }

public void setGx(String name,intgx)                            // Set gx for a node and update adjacency list
    {
int index = getIndex(name);
HeadNode node = headNodesList.get(index);
node.setGx(gx);
headNodesList.set(index, node);
    }

publicHeadNodegetHeadNode (String name){                       // Get Head node by name
returnheadNodesList.get(getIndex(name));
    }

public void setFx(Node neighbour, HeadNodecurr)                 // Set fx for neighbour via current node
    {
inttempGx = curr.getGx() + neighbour.getDistance();         // Get distance from source to neighbour via current node
HeadNodeadj = getHeadNode(neighbour.getName());             // Get adjacent head node
if(tempGx>= adj.getGx())                                    // Check if calculated distance is less than previous distance
return;

adj.setGx(tempGx);                                           // Set gx as calculated distance
headNodesList.set(getIndex(adj.getName()), adj);             // Update headnode list
    }
}

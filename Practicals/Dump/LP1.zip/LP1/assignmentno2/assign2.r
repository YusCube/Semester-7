library(caTools)
library(e1071)
install.packages('caTools')
library(caTools)
mydata <- read.csv(file = "D:\\diabetes.csv")
#, header= TRUE, sep= ",")

View(mydata)

# split data set and use it percentile split

temp_field <- sample.split(mydata,SplitRatio=0.7)

# 70% will be in training

train <- subset (mydata, temp_field==TRUE)

#30 % will be testing
test <- subset (mydata, temp_field==FALSE)

#view datasets
View (train)
View (test)

#Display few sample
head(train)
head(test)

# s3 method of formula
install.packages('e1071')
library(e1071)
my_model <-naiveBayes(as.factor(train$Outcome)~.,train)
my_model

# predicting try putting type="class" or type='raw after the test data
pred1 <- predict(my_model,test[,-9], type = "class")

pred1

# generate confusion matrix

table(pred1,test$Outcome,dnn=c("predicated","Actual"))

# to save the prediction

output <- cbind(test,pred1)

View(output)

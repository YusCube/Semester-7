#Accessing datasets
library(datasets)


#Reading files into R - Iris Data Set - The data set consists of 50 samples from each of three species of Iris
data("iris")

#display dataset 
View(iris)

#gets the names of an object.
names(iris)

#displaying the dimensions of attributes -sample size and attributes
dim(iris)

#Compactly display the internal structure of dataset
str(iris)

#statastics Calculation

#min value - return the minimum of all the values present
min(iris$Sepal.Length)

#max Value -  return the maximum of all the values present
max(iris$Sepal.Length)

#mean - return the mean of all the values present
mean(iris$Sepal.Length)

#range - return the range of all the values present
range(iris$Sepal.Length)

#standard deviations - return the Std. Deviation of all the values present
sd(iris$Sepal.Length)

#variance - return the variance of all the values present
var(iris$Sepal.Length)


# to display details of histogram 
h<- hist(iris$Sepal.Length, main="sepal length Frequences=histograms",xlab = "sepal Length",xlim = c(4,8),col = "blue")
h

# to display the boxplot
boxplot(iris$Sepal.Length)


